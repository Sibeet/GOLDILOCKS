
PWD=`pwd`

export LD_LIBRARY_PATH=$PWD/lib:$LD_LIBRARY_PATH
nohup ./bin/telegraf --config conf/telegraf.conf >> log/telegraf.log 2>&1 &
